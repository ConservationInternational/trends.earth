# API related constants
API_URL = "https://api2.trends.earth"
TIMEOUT = 30
