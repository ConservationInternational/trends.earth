"""
Description of example
"""

import numpy as np

import pyqtgraph as pg
from pyqtgraph.Qt import QtCore, QtGui, QtWidgets, mkQApp

app = mkQApp()

# win.setWindowTitle('pyqtgraph example: ____')

if __name__ == '__main__':
    pg.exec()
