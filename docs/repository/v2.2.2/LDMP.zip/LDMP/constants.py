# API related constants
API_URL = "https://api.trends.earth"
TIMEOUT = 30
