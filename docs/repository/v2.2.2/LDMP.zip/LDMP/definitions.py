# Styles

GREEN_HIGHLIGHT = "border: 1px solid green;"
RED_HIGHLIGHT = "border: 1px solid red;"
