import enum


class ProductivityMode(enum.Enum):
    TRENDS_EARTH_5_CLASS_LPD = "TrendsEarth-LPD-5"
    JRC_5_CLASS_LPD = "JRC-LPD-5"
    FAO_WOCAT_5_CLASS_LPD = "FAO-WOCAT-LPD-5"
    CUSTOM_5_CLASS_LPD = "Custom-LPD-5"
